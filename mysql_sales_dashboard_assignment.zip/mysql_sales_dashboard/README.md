# MySQL Sales Dashboard

## 作業架構

Browser
  -> index.html
  -> fetch("api.php")
  -> PHP PDO
  -> MySQL sales table
  -> JSON
  -> Chart.js
  -> charts + filters

## 第 4 題重點

不要建立 sales_original_300 與 sales_updated_300 兩張要輪流切換的網頁資料表。

老師的要求其實是：
- 第一次把 original 300 筆放進 `sales`
- 第二次用 updated 300 筆依 `sale_id` 更新同一張 `sales`
- `index.html` 永遠查 `sales`
- 所以 F5 時，API 會重新查詢 MySQL，圖表自然跟著更新

## 驗收數值

original:
- records = 300
- quantity = 3444
- returns = 33
- netRevenue = 3217100

updated:
- records = 300
- quantity = 4524
- returns = 63
- netRevenue = 3970100

changed = 240

## 上傳順序

1. 在 PHP + MySQL 主機建立資料庫。
2. 建立 `sales` 資料表。
3. 修改 `api.php` 的 4 個 DB 參數。
4. 把 `index.html`、`api.php` 上傳到網站根目錄。
5. Colab 執行 original。
6. 打開網站，F5，應顯示 original。
7. Colab 再執行 updated。
8. 回網站直接 F5，應顯示 updated。
9. GitHub 放 `index.html`、`api.php`、`sales_upload_colab.ipynb`、`setup.sql`。

## 安全提醒

不要把 MySQL 密碼寫進 index.html，也不要把真實密碼 commit 到 GitHub。
`api.php` 目前為課堂示範版；正式部署時應使用環境變數或主機的安全設定。
