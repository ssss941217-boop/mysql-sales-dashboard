<?php
// api.php
// This file is the ONLY server-side bridge between the browser and MySQL.
// Never put DB passwords in index.html.

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

// ======== CHANGE THESE 4 VALUES ========
$host = 'YOUR_MYSQL_HOST';
$db   = 'YOUR_DATABASE_NAME';
$user = 'YOUR_MYSQL_USER';
$pass = 'YOUR_MYSQL_PASSWORD';
// =======================================

try {
    $pdo = new PDO(
        "mysql:host=$host;dbname=$db;charset=utf8mb4",
        $user,
        $pass,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]
    );

    // The browser does NOT know whether data is original or updated.
    // Both versions overwrite the SAME 300-row table.
    $sql = "
        SELECT
            sale_id,
            DATE_FORMAT(sale_date, '%Y-%m-%d') AS sale_date,
            product_id,
            product_name,
            category,
            channel,
            unit_price,
            quantity,
            returned_quantity,
            unit_price * (quantity - returned_quantity) AS net_revenue
        FROM sales
        ORDER BY sale_date, sale_id
    ";

    $rows = $pdo->query($sql)->fetchAll();

    echo json_encode([
        'success' => true,
        'data' => $rows
    ], JSON_UNESCAPED_UNICODE);

} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => '資料庫連線或 SQL 查詢失敗：' . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
?>
